<?php
/*
 BMForum Datium! Bulletin Board Systems
 Version : Datium!
 
 This is a freeware, but don't change the copyright information.
 A SourceForge Project.
 Web Site: http://www.bmforum.com
 Copyright (C) Bluview Technology
*/

require("include/db/db_{$sqltype}.php");
// 输入禁止由 Lite 访问的版块 ID
$forumidbanned = ""; // 逗号隔开，如 99,100,101
$perpage = "100"; // 每页显示主题
// 其余部分非专业人士勿动
$forumidban = explode(",", $forumidbanned);
bmbdb_connect($db_server, $db_username, $db_password, $db_name, 0, $mysqlchar);
$ugsocount = 0;
include_once("datafile/cache/usergroup.php");
include_once("datafile/cache/forumdata.php");

global_usergroup();
function readfromfile($file_name)
{
    if (file_exists($file_name)) {
        $filenum = fopen($file_name, "r");
        flock($filenum, LOCK_SH);
        $file_data = @fread($filenum, @filesize($file_name));
        fclose($filenum);
        return $file_data;
    } 
} 
function global_usergroup()
{
    global $p_read_post, $enter_tb, $canpost, $canreply, $bmfcode_post, $usergroupdata, $ugnums, $view_list;
    list($groupname, $groupimg, $systemg, $canpost, $canreply, $canpoll, $canvote, $max_sign_length, $sign_use_bmfcode, $bmfcode_sign['pic'], $bmfcode_sign['flash'], $bmfcode_sign['fontsize'], $enter_tb, $send_msg, $max_post_length, $short_msg_max, $send_msg_max, $use_own_portait, $swf, $max_upload_size, $upload_type_available, $supermod, $admin, $groupimg2, $mod, $max_upload_num, $html_codeinfo, $max_daily_upload_size, $logon_post_second, $post_sell_max, $del_true, $del_rec, $can_rec, $delrmb, $post_money, $deljifen, $post_jifen, $allow_upload, $max_upload_post, $opencutusericon, $openupusericon, $max_avatars_upload_size, $max_avatars_upload_post, $upload_avatars_type_available, $maxwidth, $maxheight, $p_read_post, $view_list, $lock_true, $del_reply_true, $edit_true, $move_true, $copy_true, $ztop_true, $ctop_true, $uptop_true, $bold_true, $sej_true, $autorip_true, $ttop_true, $modcenter_true, $modano_true, $modban_true, $clean_true, $showpic, $post_money_reply, $post_jifen_reply, $del_self_topic, $del_self_post, $bmfcode_post['pic'], $bmfcode_post['reply'], $bmfcode_post['jifen'], $bmfcode_post['sell'], $bmfcode_post['flash'], $bmfcode_post['mpeg'], $bmfcode_post['iframe'], $bmfcode_post['fontsize'], $bmfcode_post['hpost'], $bmfcode_post['hmoney'], $allow_forb_ub, $can_visual_post, $member_list, $search_fun, $nwpost_list, $porank_list, $gvf, $see_amuser, $view_recybin) = explode("|", $usergroupdata[6]);
} 
function get_forum_info()
{
    global $p_read_post, $forum_ford, $fileqtype, $forumscount, $forumidban, $enter_this_forum, $sxfourmrow, $view_list, $ttopicnum, $forum_type, $noheldtop, $forum_cid, $usergroupdata, $database_up, $forumid;

    for($i = 0;$i < $forumscount;$i++) {
        if ($sxfourmrow[$i]['id'] == $forumid) {
            $detail = $sxfourmrow[$i];
        } 
    } 

    $ttopicnum = $detail['topicnum'];
    $forum_type = $detail['type'];
    $forum_ford = $detail['forum_ford'];
    $forum_cid = $detail['forum_cid'];
    $guestpost = explode("_", $detail['guestpost']);
    $noheldtop = $guestpost[2];
    $spusergroup = $detail['spusergroup'];

    if ($spusergroup == "1") {
        $usergroupdata = explode("\n", $detail['usergroup']);
        $usertype = explode("|", $usergroupdata[6]);
        list($groupname, , , $canpost, $canreply, $canpoll, $canvote, , , , , , $enter_this_forum, , $max_post_length, , , , , $max_upload_size, $upload_type_available, , , , $mod, $max_upload_num, $html_codeinfo, $max_daily_upload_size, $logon_post_second, $post_sell_max, $del_true, $del_rec, $can_rec, $delrmb, $post_money, $deljifen, $post_jifen, $allow_upload, $max_upload_post, , , , , , , , $p_read_post, $view_list, $lock_true, $del_reply_true, $edit_true, $move_true, $copy_true, $ztop_true, $ctop_true, $uptop_true, $bold_true, $sej_true, $autorip_true, $ttop_true, $modcenter_true, $modano_true, $modban_true, $clean_true, , $post_money_reply, $post_jifen_reply, $del_self_topic, $del_self_post, $bmfcode_post['pic'], $bmfcode_post['reply'], $bmfcode_post['jifen'], $bmfcode_post['sell'], $bmfcode_post['flash'], $bmfcode_post['mpeg'], $bmfcode_post['iframe'], $bmfcode_post['fontsize'], $bmfcode_post['hpost'], $bmfcode_post['hmoney'], $allow_forb_ub, $can_visual_post) = explode("|", $usergroupdata[6]);
        if ($enter_this_forum == 0) $forumidban[] = $forumid;
        if ($view_list == 0 && $fileqtype == "f") $forumidban[] = $forumid;
        if (($p_read_post == "0" || 0 < $read_allow_ww) && $fileqtype == "t") $forumidban[] = $forumid;
    } 
    

} 
function writetofile($file_name, $data, $method = "w")
{
    $filenum = fopen($file_name, $method);
    flock($filenum, LOCK_EX);
    $file_data = fwrite($filenum, $data);
    fclose($filenum);
    return $file_data;
} 
function get_user_info($user, $type = "username")
{
    global $database_up;
    if ($type == "username") {
        $query = "SELECT * FROM {$database_up}userlist WHERE username='$user'";
    } elseif ($type == "usrid") {
        $query = "SELECT * FROM {$database_up}userlist WHERE userid='$user'";
    } 
    $result = bmbdb_query($query, 0);
    $row = bmbdb_fetch_array($result);
    return $row;
} 
function getCode ($length = 9, $type = 0)
{
    $str = $type ? 'ABCEFHJKMNPRSTUVWXY13456789' : 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890';
    $result = '';
    $l = strlen($str) - 1;

    for($i = 0;$i < $length;$i ++){
        $num = rand(0, $l);
        $result .= $str{$num};
    }
    return $result;
}
$timestamp = time();
$ip = $_SERVER['REMOTE_ADDR'];
$ip1 = getenv('HTTP_X_FORWARDED_FOR');
if (($ip1 != "") && ($ip1 != "unknown")) $ip = $ip1;
