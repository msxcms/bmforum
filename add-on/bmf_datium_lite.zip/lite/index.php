<?php
/*
 BMForum Datium! Bulletin Board Systems
 Version : Datium!
 
 This is a freeware, but don't change the copyright information.
 A SourceForge Project.
 Web Site: http://www.bmforum.com
 Copyright (C) Bluview Technology
*/

error_reporting(E_ERROR | E_WARNING | E_PARSE);
// 手动配置绝对路径
$dirchange = ".."; // 注意用反斜杆 “/”
// 用于无法正常使用
$main_string = $_SERVER['REQUEST_URI'] ? $_SERVER['REQUEST_URI'] : $_SERVER['PHP_SELF'];
if (substr(PHP_OS, 0, 3) == 'WIN' OR strstr(php_sapi_name(), 'cgi') OR php_sapi_name() == 'apache2filter') {
    if (PHP_VERSION >= "5.0.0") {
        define('SERVER' , 'UNX');
    } else define('SERVER' , 'WIN');
} else {
    define('SERVER' , 'UNX');
} 
if (SERVER == 'WIN' || $_GET['mode'] == 1) {
    if ($_GET['mode'] == 1) $mode_add = "mode=1&";
    else { $mode_add = ""; $full_add = "../";}
    $winpath = "?{$mode_add}";
    $cpath = "{$mode_add}";
    if (empty($cpath)) $cpath = "?";
    $main_string = $_SERVER['QUERY_STRING'];
} else {
	$full_add = "../";
    $cpath = '/';
    $winpath = '';
} 
chdir($dirchange);
include_once("datafile/config.php");
header("Content-type: text/html; charset=utf-8");
include("lite/global.php");
include("include/readpost.func.php");

$jiexi = explode($cpath, $main_string);
$count = count($jiexi);
$filequery = eregi_replace(".html", "", $jiexi[$count-1]);
$infoqtype = explode("-", $filequery);
$fileqtype = $infoqtype[0];
require_once("datafile/time.php");

if ($fileqtype == "t") {
    $filename = $infoqtype[1];
    $fullurl = "{$full_add}../topic.php?filename=$infoqtype[1]";

    $query = "SELECT * FROM {$database_up}threads WHERE tid='$filename'";
    $result = bmbdb_query($query);
    $row = bmbdb_fetch_array($result);
    $threadrow = $row;
    $replyerlist = explode("|", $row['replyer']);
    $forumid = $row[forumid];
    $thtoptype = $row[toptype];
    $topic_reply = $row['replys'];
    
    get_forum_info();
    check_forum_permission();

    for($i = 0;$i < $forumscount;$i++) {
    	$detail = $sxfourmrow[$i];
        if ($forumid == $detail['id'] && (($detail['forumpass'] <> "" && $detail['forumpass'] <> "d41d8cd98f00b204e9800998ecf8427e") || ($detail['type'] != 'subforum' && $detail['type'] != 'subselection' && $detail['type'] != 'selection' && $detail['type'] != 'forum'))) {
            $forumidban[] = $forumid;
        } 
        if ($forumid == $detail['id']) {
            $forumname = $detail['bbsname'];
        } 

    } 

    get_forum_info();
    check_forum_permission();
    $echoinfo .= <<<EOT
<tr><td bgcolor="#F8F8F8" class="bold"><a href="./$winpath"><b>$bbs_title</b> <small>Lite</small></a> <span class="smalltxt"><small>&gt;&gt;</small></span> <a href="{$winpath}f-$forumid.html">$forumname</a></td></tr></table><br><br>
EOT;

    if (@in_array($forumid, $forumidban) || $p_read_post != 1) {
        $echoinfo .= "
<p align=\"center\">您无权访问本版块 [<a href=\"./\">返回</a>]</p>
<p align=\"center\">Powered by <a href=\"http://www.bmforum.com/bmb/lite/\">BMForum Datium! Lite</a></p>
";
    } else {
        include("include/bmbcodes.php");
        $page = $infoqtype[2];
        $qbgcolor = "#F8F8F8";

        if (empty($page)) $page = 1;

        $count = $topic_reply + 1;

        if ($count % $read_perpage == 0) $maxpageno = $count / $read_perpage;
        else $maxpageno = floor($count / $read_perpage) + 1;
        if ($page == "last" || $page > $maxpageno) $page = $maxpageno;
        $pagemin = min(($page-1) * $read_perpage , $count-1);
        $pagemax = min($pagemin + $read_perpage-1, $count-1);

        $pagemaxq = $pagemax + 1;

        $aquery = "SELECT o.* FROM {$database_up}posts o WHERE o.tid='$filename' ORDER BY o.id ASC LIMIT $pagemin,$pagemaxq";
        $aresult = bmbdb_query($aquery);

        for ($i = $pagemin; $i <= $pagemax; $i++) {
            $line = bmbdb_fetch_array($aresult);
            if ($line['articlecontent'] == "") continue;

            $icountforend = count($articlelist);
            // list("articletitle"=>$title,"username"=>$author,"articlecontent"=>$content,"timestamp"=>$time,"ip"=>$aaa,"usericon"=>$icon,"options"=>$usesign,"other1"=>$bym,"other2"=>$bymuser,"other3"=>$uploadfilename,"other4"=>$editinfo,"other5"=>$sellmoney)=$line;
            $title = stripslashes($line[articletitle]);
            $author = $line[username];
            $content = $line[articlecontent];
            $time = $line[timestamp];
            $aaa = $line[ip];
            $icon = $line[usericon];
            $usesign = $line[options];
            $bym = $line[other1];
            $bymuser = $line[other2];
            $uploadfilename = $line[other3];
            $editinfo = $line[other4];
            $sellmoney = $line[other5];
            if (!$topicname) {
                $topicname = "yes";
                $bbs_title = str_replace("%a%", "", $title) . " - $bbs_title";
            } 

            $content = str_replace("[img]act", "[img]../../act", stripslashes($content));
            $somepostinfo = explode("_", $usesign);
            $userinfoget = get_user_info($author);
            $usertype = $userinfoget['ugnum'];
            list($groupname, $groupimg, $systemg, $canpost, $canreply, $canpoll, $canvote, $max_sign_length, $sign_use_bmfcode, $bcode_sign['pic'], $bcode_sign['flash'], $bcode_sign['fontsize'], $enter_tb, $send_msg, $max_post_length, $short_msg_max, $send_msg_max, $use_own_portait, $swf, $max_upload_size, $upload_type_available, $supermod, $admin, $groupimg2, $mod, $max_upload_num, $html_codeinfo, $max_daily_upload_size, $logon_post_second, $post_sell_max, $del_true, $del_rec, $can_rec, $delrmb, $post_money, $deljifen, $post_jifen, $allow_upload, $max_upload_post, $opencutusericon, $openupusericon, $max_avatars_upload_size, $max_avatars_upload_post, $upload_avatars_type_available, $maxwidth, $maxheight, $p_read_post, $view_list, $lock_true, $del_reply_true, $edit_true, $move_true, $copy_true, $ztop_true, $ctop_true, $uptop_true, $bold_true, $sej_true, $autorip_true, $ttop_true, $modcenter_true, $modano_true, $modban_true, $clean_true, $showpic, $post_money_reply, $post_jifen_reply, $del_self_topic, $del_self_post, $bcode_post['pic'], $bcode_post['reply'], $bcode_post['jifen'], $bcode_post['sell'], $bcode_post['flash'], $bcode_post['mpeg'], $bcode_post['iframe'], $bcode_post['fontsize'], $bcode_post['hpost'], $bcode_post['hmoney'], $allow_forb_ub, $can_visual_post, $member_list, $search_fun, $nwpost_list, $porank_list, $gvf, $see_amuser, $view_recybin) = explode("|", $usergroupdata[$usertype]);
            if ($somepostinfo[1] != "checkbox") $content = bmbconvert($content, $bcode_post);
            $content = str_replace("<img src='face/", "<img src='../../face/", $content);
            
			if ($bmfopt['text_wm']) {
				$content = text_watermark($content);
			}

            $echoinfo .= "<table cellspacing=\"1\" cellpadding=\"4\" width=\"99%\" align=\"center\" class=\"tableborder\">
<tr><td bgcolor=\"#F8F8F8\"><table cellspacing=\"0\" cellpadding=\"0\" width=\"100%\"><td class=\"bold\">$author</td><td align=\"right\">" . getfulldate($time) . "</td></tr></table></td></tr>
<tr><td bgcolor=\"#FFFFFF\" class=\"smalltxt\"><b>" . str_replace("%a%", "", $title) . "</b><br><br>$content</td></tr>
</table><br>
";
        } 

        if ($count % $read_perpage == 0) $maxpageno = $count / $read_perpage;
        else $maxpageno = floor($count / $read_perpage) + 1;
        if ($page == "last" || $page > $maxpageno) $page = $maxpageno;
        $pagemin = min(($page-1) * $read_perpage , $count-1);
        $pagemax = min($pagemin + $read_perpage-1, $count-1);

        $echoinfo .= <<<EOT
<table cellspacing="1" cellpadding="4" width="99%" align="center" class="tableborder">
<tr><td bgcolor="#FFFFFF">

EOT;

        if ($maxpageno == 1) $pageinfos .= "<strong>当前只有一页</strong>";
        else {
            $pageinfos .= "[ ";
            $nextpage = $page + 1;
            $previouspage = $page-1;
            $maxpagenum = $page + 4;
            $minpagenum = $page-4;
            if ($page >= 2) $pageinfos .= "<strong><a href=\"{$winpath}t-$filename-$previouspage.html\">&lt;</a></strong> ";
            else $pageinfos .= "<strong>&lt;</strong> ";
            if ($page <= $maxpageno-1) $pageinfos .= "<strong><a href=\"{$winpath}t-$filename-$nextpage.html\">&gt;</a></strong> ";
            else $pageinfos .= "<strong>&gt;</strong> ";

            $pageinfos .= "<strong><a href=\"{$winpath}t-$filename.html\">&lt;&lt;</a></strong> <strong><a href=\"{$winpath}t-$filename-$maxpageno.html\">&gt;&gt;</a></strong> ";
            for ($i = $minpagenum; $i <= $maxpagenum; $i++) {
                if ($i > 0 && $i <= $maxpageno) {
                    if ($i == $page) {
                        $pageinfos .= " <strong>$i</strong> ";
                    } else {
                        $pageinfos .= " <strong><a href=\"{$winpath}t-$filename-$i.html\">$i</a></strong> ";
                    } 
                } 
            } 
            $pageinfos .= "]";
        } 

        $echoinfo .= $pageinfos;
    } 
} elseif ($fileqtype == "f") {
    $forumid = $infoqtype[1];
    $fullurl = "{$full_add}../forums.php?forumid=$forumid";

    $echoinfo .= <<<EOT
<tr><td bgcolor="#F8F8F8" class="bold"><a href="./$winpath"><b>$bbs_title</b> <small>Lite</small></a></td></tr></table><br><br>
<table cellspacing="1" cellpadding="4" width="99%" align="center" class="tableborder">
<tr><td bgcolor="#FFFFFF">
EOT;

    for($i = 0;$i < $forumscount;$i++) {
    	$detail = $sxfourmrow[$i];
        if ($forumid == $detail['id'] && (($detail['forumpass'] <> "" && $detail['forumpass'] <> "d41d8cd98f00b204e9800998ecf8427e") || ($detail['type'] != 'subforum' && $detail['type'] != 'subselection' && $detail['type'] != 'selection' && $detail['type'] != 'forum'))) {
            $forumidban[] = $forumid;
        } 
        if (($detail['type'] == 'subforum' || $detail['type'] == 'subselection') && $detail['blad'] == $forumid) {
            if ($chnas == 0) {
                $echoinfo .= "<p align=\"left\"><strong>&nbsp;&nbsp;&nbsp;[版块列表]</strong></p><ul>";
                $chnas = 1;
            } 
            forum_line($detail['type'], $detail, $line);
        } 
    } 
    
    get_forum_info();
    check_forum_permission();
    

    if (@in_array($forumid, $forumidban) || $view_list != 1) {
        $echoinfo .= "
<p align=\"center\">您无权访问本版块 [<a href=\"./\">返回</a>]</p>
<p align=\"center\">Powered by <a href=\"http://www.bmforum.com/bmb/lite/\">BMForum Datium! Lite</a></p>

";
    } else {
        $orderby = "ORDER BY `toptype` DESC,`changetime` DESC";
        $jinhuasql = $chooseby = $hasacount = "";
        $trashq = "AND ttrash=0";
        $jinhuasql = "islock > 1 AND";
        $hasacount = $digestcount;
	
        $echoinfo .= "</ul></ul><p align=\"left\"><strong>&nbsp;&nbsp;&nbsp;[主题列表]</strong></p><p align=left><ul>";

        $page = $infoqtype[2];
        if (empty($page)) $page = 1;

        get_forum_info();
        check_forum_permission();

        @include_once("datafile/cache/pin_thread.php");

        $query_pagea = "";
        if (empty($forum_cid)) $forum_cid = "XXXXXXXXXXXX";
    
        $intopthread = $count_pint["$forum_cid"] ? $topthread['ALL'] : substr($topthread['ALL'] ,0 ,-1);
        $intopthread .=  substr($topthread["$forum_cid"] ,0 ,-1);

        $total_pin = $count_pint['ALL'] + $count_pint["$forum_cid"];
        
        
        if ($page == 1 && $total_pin > 0) {
            $query = "SELECT * FROM {$database_up}threads WHERE tid in ($intopthread) $trashq $chooseby $orderby";
            $xresult = bmbdb_query($query);
            $counttopsnum = $topsnum = bmbdb_num_rows($xresult);
        } elseif ($page != 1 && $total_pin > 0) {
            $query = "SELECT COUNT(tid) FROM {$database_up}threads WHERE tid in ($intopthread) $trashq $chooseby $orderby";
            $xresult = bmbdb_query($query);
            $xresultrow = bmbdb_fetch_array($xresult);
            $topsnum = $xresultrow['COUNT(tid)'];
            $counttopsnum = $topsnum + $pincount;
        } else {
            $counttopsnum = $topsnum;
        }
        
        
        $thislimit = $perpage * $page;
        $lastlimit = $perpage * ($page-1);
        
        if ($ttopicnum < $perpage) $perpage = $ttopicnum;

        $query = "SELECT * FROM {$database_up}threads WHERE forumid='$forumid' AND toptype!=9 AND toptype!=8 $trashq $chooseby $orderby LIMIT $lastlimit,$perpage";
        $result = bmbdb_query($query);
        $topicsn = bmbdb_num_rows($result) + $topsnum;
        $count = max(0, $ttopicnum - $counttopsnum);
        $x = 0;
        $xxi = 0;
        for ($x = 0;$x < $topicsn;$x++) {
            if ($x < $topsnum) $row = bmbdb_fetch_array($xresult);
            else $row = bmbdb_fetch_array($result);
            
            $showto[] = $row;
        } 
        // ===================================
        // Stat posts
        // ===================================
        
        for ($i = 0; $i < $topicsn; $i++) {
            if ($showto[$i]['tid'] != "") {
                $echoinfo .= "<li><a href=\"{$winpath}t-{$showto[$i]['tid']}.html\">" . str_replace("%a%", "", stripslashes($showto[$i]['title'])) . "</a> (<i>{$showto[$i]['author']} 发表于 " . getfulldate($showto[$i]['time']) . "</i>)</li>\n";
            } 
        } 
        
        if ($count == 0) {
            $pagemin = $pagemax = $page = $maxpageno = 1;
        }else{
            if ($count % $perpage == 0) $maxpageno = max(1, $count / $perpage);
            else $maxpageno = max(1, floor($count / $perpage) + 1);
            if ($page == "last" || $page > $maxpageno) $page = $maxpageno;
            $pagemin = max(1, min(($page-1) * $perpage , $count-1));
            $pagemax = max(1, min($pagemin + $perpage-1, $count-1) + 1);
        }



        $echoinfo .= "</ul>";
        if ($maxpageno == 1) $pageinfos .= "<strong>当前只有一页</strong>";
        else {
            $pageinfos .= "[ ";
            $nextpage = $page + 1;
            $previouspage = $page-1;
            $maxpagenum = $page + 4;
            $minpagenum = $page-4;
            if ($page >= 2) $pageinfos .= "<strong><a href=\"{$winpath}f-$forumid-$previouspage.html\">&lt;</a></strong> ";
            else $pageinfos .= "<strong>&lt;</strong> ";
            if ($page <= $maxpageno-1) $pageinfos .= "<strong><a href=\"{$winpath}f-$forumid-$nextpage.html\">&gt;</a></strong> ";
            else $pageinfos .= "<strong>&gt;</strong> ";

            $pageinfos .= "<strong><a href=\"{$winpath}f-$forumid.html\">&lt;&lt;</a></strong> <strong><a href=\"{$winpath}f-$forumid-$maxpageno.html\">&gt;&gt;</a></strong> ";
            for ($i = $minpagenum; $i <= $maxpagenum; $i++) {
                if ($i > 0 && $i <= $maxpageno) {
                    if ($i == $page) {
                        $pageinfos .= " <strong>$i</strong> ";
                    } else {
                        $pageinfos .= " <strong><a href=\"{$winpath}f-$forumid-$i.html\">$i</a></strong> ";
                    } 
                } 
            } 
            $pageinfos .= "]";
        } 
        $echoinfo .= $pageinfos;
    } 
} else {
    $fullurl = "{$full_add}../";

    $echoinfo .= <<<EOT
<tr><td bgcolor="#F8F8F8" class="bold"><a href="./$winpath"><b>$bbs_title</b> <small>Lite</small></a></td></tr></table><br><br>
<table cellspacing="1" cellpadding="4" width="99%" align="center" class="tableborder">
<tr><td bgcolor="#FFFFFF">
EOT;

    for($i = 0;$i < $forumscount;$i++) {
    	$detail = $sxfourmrow[$i];
        if ($detail['type'] == 'forum' || $detail['type'] == 'selection') forum_line($detail['type'], $detail, $line);
        elseif ($detail['type'] == 'category') {
            category_line($detail['bbsname'], $detail['id'], $detail);
        } 
    } 

} 

function category_line($name, $categoryid)
{
    global $echoinfo, $catea, $cateb, $temfilename, $fenleiq, $i, $otherimages, $forum_cidi;
    $echoinfo .= "</ul></ul><ul><li><b>$name</b></li><ul>\n";
} 
function forum_line($forum_type, $id, $detail)
{
    global $forum_line, $xxxcount, $echoinfo, $winpath, $forumlist, $preoutput, $po, $temfilename, $all_count, $all_lastmo, $time_2, $time_1, $script_pos, $forum_admin, $login_status, $idpath, $newpost, $onlyread, $nonewpost, $posticon, $pollicon, $ucomicon, $otherimages, $timestamp, $minoffset;
    $echoinfo .= "<li><a href=\"{$winpath}f-{$id['id']}.html\">" . str_replace("&", "&amp;", $id['bbsname']) . "</a></li>\n";
} 

function get_date_chi($datetime)
{
    global $minoffset, $time_1;
    $datetime = $datetime + ($time_1 * 60 * 60);
    return gmdate("Y/m/d/", $datetime);
} 

function getfulldate($datetime)
{
    global $minoffset, $time_1;
    $datetime = $datetime + ($time_1 * 60 * 60);
    return gmdate("Y/m/d/H:i", $datetime);
} 
function get_time($datetime)
{
    global $minoffset, $time_1;
    $datetime = $datetime + ($time_1 * 60 * 60);
    return gmdate("H:i", $datetime);
} 
function get_date($datetime)
{
    global $minoffset, $time_1;
    $datetime = $datetime + ($time_1 * 60 * 60);
    return gmdate("Y/m/d", $datetime);
} 
// UNIX 时间转换
function get_stamp($last_str)
{
    list($last_date, $last_time) = explode(" ", $last_str);
    list($y, $m, $d) = explode("-", $last_date);
    list($h, $minute) = explode(":", $last_time);
    return mktime($h, $minute, 0, $m, $d, $y);
} 
function diplay_attachment($start, $countas, $lineid, $getcode) {
    
}
function check_forum_permission()
{
    global $usermoney, $forumidban, $cannotenter, $ajax_online, $enter_this_forum, $gl, $forumid, $forum_name, $p_read_post, $pgo, $ajax_reply, $error, $language, $read_allow_ww, $spusergroup, $postamount, $userbym , $forum_ford, $footer_copyright, $headername, $footername, $read_alignment, $html_lang, $enter_allow_ww, $enter_this_forum, $userpoint, $enter_tb, $plugyescolor, $usertype, $forum_type, $forumid, $username, $login_status, $limitlist, $forum_admin, $verandproname, $otherimages, $bbs_title, $add_title, $cssinfo, $login_status, $ads_select, $admin_email, $site_url, $showtime, $site_name, $writefilenum, $readfilenum, $begin_time, $temfilename, $gl;
    $usermoney = $userpoint = $userbym = $postamount = $login_status = 0;
	$ford = explode("_", $forum_ford);
	if ($ford[0] == 1 && ($postamount < $ford[1] || $userbym < $ford[2] || $usermoney < $ford[3]) && $usertype[21] != "1" && $usertype[22] != "1") {
		$forumidban[] = $forumid;
	} 

} 
?>
<html>
<head>
<title><?php echo $bbs_title?> - powered by BMForum.com</title>
<meta name="keywords" content="php,bmb,bmf,蓝色,魔法,论坛,bbs,bmforum,text,蓝魔,免费"> 
<META NAME="robots" CONTENT="index, follow">
<META NAME="GOOGLEBOT" CONTENT="INDEX, FOLLOW">
<style type="text/css">
a			{ text-decoration: none; color: #003366 }
a:hover			{ text-decoration: underline }
body			{ scrollbar-base-color: #F8F8F8; scrollbar-arrow-color: #698CC3; font-size: 9pt; background-color: #9EB6D8 }
table			{ font-family: Tahoma, Verdana; font-size: 9pt; color: #000000 }
li			{ padding: 2px }
.tableborder		{ background: #D6E0EF; border: 1px solid #698CC3 } 
.smalltxt		{ font-family: Tahoma, Verdana; font-size: 9pt }
.bold			{ font-weight: bold }
</style>
</head>
<body leftmargin="10" rightmargin="10" topmargin="10">
<table width="100%" cellpadding="8" cellspacing="0" border="0" align="center" class="tableborder">
<tr><td bgcolor="#FFFFFF"><br><table cellspacing="1" cellpadding="4" width="99%" align="center" class="tableborder">
<?php echo $echoinfo?>
</td></tr></table>
<br><table cellspacing="0" cellpadding="0" width="99%" align="center">
<tr><td class="bold"><a href=<?php echo $fullurl?>>查看完整版本</a><br><br>
</td></tr></table>
<p align="center">Powered by <a href="http://www.bmforum.com/bmb/lite/">BMForum - Lite</a></p>
