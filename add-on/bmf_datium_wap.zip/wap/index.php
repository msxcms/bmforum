<?php
/*
 BMForum Bulletin Board Systems
 Version : Datium!
 
 This is a freeware, but don't change the copyright information.
 A SourceForge Project.
 Web Site: http://www.bmforum.com
 Copyright (C) Bluview Technology
*/

chdir("..");
include_once("datafile/config.php");
if (stristr($_SERVER["HTTP_USER_AGENT"], "Firefox") || stristr($_SERVER["HTTP_USER_AGENT"], "MSIE")) {
	header("Location: ../");
	exit;
}
header("Content-type: text/vnd.wap.wml; charset=utf-8");
echo '<?xml version="1.0" encoding="utf-8" ?><!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">';

?>
<wml>
<card id="BMForum" title="<?php echo $bbs_title?>" newcontext="true">
<p align="center"><b><?php echo $bbs_title?></b> <small>@WAP</small><br/></p>
<?php

function category_line($name, $categoryid)
{
    global $catea, $cateb, $temfilename, $fenleiq, $i, $otherimages, $forum_cidi;
    echo "<p align=\"left\"><b>" . strip_tags($name) . "</b></p>\n";
} 
function forum_line($forum_type, $id, $detail)
{
    global $forum_line, $xxxcount, $forumlist, $preoutput, $po, $sessionid, $temfilename, $all_count, $all_lastmo, $time_2, $time_1, $script_pos, $forum_admin, $login_status, $idpath, $newpost, $onlyread, $nonewpost, $posticon, $pollicon, $ucomicon, $otherimages, $timestamp, $minoffset;
    echo "<p align=\"left\"><a href=\"forums.php?forumid={$id['id']}{$sessionid}\">" . str_replace("&", "&amp;", strip_tags($id['bbsname'])) . "</a></p>\n";
} 
// UNIX 时间转换
function get_stamp($last_str)
{
    list($last_date, $last_time) = explode(" ", $last_str);
    list($y, $m, $d) = explode("-", $last_date);
    list($h, $minute) = explode(":", $last_time);
    return mktime($h, $minute, 0, $m, $d, $y);
} 

include("wap/global.php");

$query = "SELECT * FROM {$database_up}forumdata ORDER BY `showorder` ASC";
$result = bmbdb_query($query);
while ($tmpline = bmbdb_fetch_array($result)) {
    $line[] = $tmpline;
} 
$xxxcount = count($line);
for($i = 0;$i < $xxxcount;$i++) {
    if ($line[$i]['type'] == 'forum' || (($sxfourmrow[$i]['type'] == 'selection' || $sxfourmrow[$i]['type'] == 'hidden') && $enter_tb == 1) || ($line[$i]['type'] == 'forumhid' && $ugnums != 6) || $line[$i]['type'] == 'former' || $line[$i]['type'] == 'locked') forum_line($line[$i]['type'], $line[$i], $line);
    elseif ($line[$i]['type'] == 'category') {
        category_line($line[$i]['bbsname'], $line[$i]['id'], $line[$i]);
    } 
} 

if ($_SESSION['username'] && $_SESSION['password'] && checkpass($_SESSION['username'], $_SESSION['password'])) {
    echo "<p align=\"right\"><br/><br/><b>欢迎,{$_SESSION['username']} [<a href=\"login.php?a=out{$sessionid}\">退出</a>]</b></p>";
} else {

    ?>
<p align="right"><br/><br/><b>登录</b></p>
<p align="right">用户名:<input emptyok="false" name="word"/><br/>
密　码:<input name="wordt" type="password" maxlength="18"/>
<br/>
<anchor>登录
<go href="login.php<?php echo $sessionidq?>" method="post">
   <postfield name="pass" value="$(wordt)"/>
   <postfield name="user" value="$(word)"/>
</go>
</anchor></p>
<?php } 
?>
<p align="center">Powered by <a href="http://www.bmforum.com/bmb/wap/">BMForum WAP</a></p>
</card>
</wml>