<?php
/*
 BMForum Bulletin Board Systems
 Version : Datium!
 
 This is a freeware, but don't change the copyright information.
 A SourceForge Project.
 Web Site: http://www.bmforum.com
 Copyright (C) Bluview Technology
*/

chdir("..");
include_once("datafile/config.php");
include("wap/global.php");
header("Content-type: text/vnd.wap.wml; charset=utf-8");
echo '<?xml version="1.0" encoding="utf-8" ?><!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">';

?>
<wml>
<card id="BMForum" title="<?php echo $bbs_title?>" newcontext="true">
<p align="center"><strong><?php echo $bbs_title?></strong> <small>@WAP</small><br/></p>
<?php
$forumid = $_GET['o'];
$filename = $_GET['f'];
if (in_array($forumid, $forumidban) || ($canpost != 1 && $_GET['a'] != "r") || ($canreply != 1 && $_GET['a'] == "r") || $cannotenter || $forum_pwd || $forum_type == "locked" || $forum_type == "sublocked") {
    echo<<<EOT
<p align="center">您无权访问本版块或发帖 [<a href="index.php{$sessionidq}">返回</a>]</p>
<p align="center">Powered by <a href="http://www.bmforum.com/bmb/wap/">BMForum WAP</a></p>
</card>
</wml>
EOT;
    exit;
} 
get_forum_info();

if ($_SESSION['username'] && $_SESSION['password'] && checkpass($_SESSION['username'], $_SESSION['password'])) {
    if ($_GET['a'] == "r") {
        $xquery = "SELECT * FROM {$database_up}threads WHERE id='$filename'";
        $xresult = bmbdb_query($xquery);
        $uresult = bmbdb_fetch_array($xresult);
    } 

    if ($uresult['id'] == "" && $_GET['a'] == "r") {
        echo "<p align=\"center\">该主题不存在,无法进行回复操作.</p>";
    } else {
        if ($_GET['a'] == "r") {
            if ($_GET['st'] == 2) {
                if (empty($_POST['content']) || empty($_POST['title'])) {
                    echo "<p align=\"center\"><a href=\"forums.php?forumid=$forumid{$sessionid}\">请填写完整</a></p>";
                } else {
                    $usericon = "ran";
                    $articletitle = stripslashes($_POST['title']);
                    $articletitle = str_replace(",", "，", $articletitle);
                    $articletitle = safe_convert($articletitle);
                    $articlecontent = safe_convert($_POST['content']);
                    $username = $_SESSION['username'];
                    $asellmoney = ""; 
                    // -----Do some preparation---
                    $lm = $articletitle . "," . $username . "," . $timestamp;

                    $query = "SELECT * FROM {$database_up}posts ORDER BY `id` DESC  LIMIT 0,1 ";
                    $result = bmbdb_query($query);
                    $linexx = bmbdb_fetch_array($result);
                    $newlineno = $linexx['id'] + 1;

                    $query = "SELECT * FROM {$database_up}threads WHERE tid='$filename'";
                    $result = bmbdb_query($query);
                    $line = bmbdb_fetch_array($result);
                    $adduserline = $line['replyer'] . "$userid|";

                    if ($noheldtop != 1) $changadd = ", changetime = '$timestamp'";

                    $nquery = "UPDATE {$database_up}threads SET  replyer='$adduserline',replys = replys+1 , lastreply = '$lm' $changadd WHERE tid = '$filename'";
                    $result = bmbdb_query($nquery);

                    $nquery = "insert into {$database_up}posts (id,tid,articletitle,username,usrid,ip,usericon,options,other1,other2,other3,other4,other5,addin,articlecontent,timestamp,forumid,changtime) values ('$newlineno','$filename','$articletitle','$username','$userid','$ip','$usericon','$options','$other1','$other2','$other3','$other4','$other5','','$articlecontent','$timestamp','$forumid','$timestamp')";
                    $result = bmbdb_query($nquery);
                    
                    send_suc();

                    echo "<p align=\"center\"><a href=\"topic.php?o=$forumid&amp;f=$filename{$sessionid}\">发表完成,点击这里返回.</a></p>";
                } 
            } else {
                ?>
<p align="center"><br/><br/><b>发表回复</b></p>
<p align="left">标题:<input emptyok="false" value="RE:<?php echo $uresult['title'];?>" name="title" /><br/>
内容:<input emptyok="false" name="content"/>
<br/>
<anchor>提交
<go href="post.php?st=2&amp;o=<?php echo $forumid?>&amp;f=<?php echo $filename?>&amp;a=r<?php echo $sessionid?>" method="post">
   <postfield name="title" value="$(title)"/>
   <postfield name="content" value="$(content)"/>
</go>
</anchor></p><?php
            } 
        } else {
            if ($_GET['st'] == 2) {
                if (empty($_POST['content']) || empty($_POST['title'])) {
                    echo "<p align=\"center\"><a href=\"forums.php?forumid=$forumid{$sessionid}\">请填写完整</a></p>";
                } else {
                    $usericon = "ran";
                    $articlecontent = safe_convert($_POST['content']);
                    $articletitle = str_replace('%a%', '', $_POST['title']);
                    $articletitle = stripslashes(safe_convert($articletitle));
                    $articletitle = str_replace(",", "，", $articletitle);

                    $username = $_SESSION['username'];

                    $lm = $articletitle . "," . $username . "," . $timestamp;

                    $query = "SELECT * FROM {$database_up}posts ORDER BY `id` DESC  LIMIT 0,1 ";
                    $result = bmbdb_query($query);
                    $linexx = bmbdb_fetch_array($result);
                    $newlineno = $linexx['id'] + 1;

                    $nquery = "insert into {$database_up}threads (id,tid,toptype,ttrash,lastreply,topic,forumid,hits,replys,changetime,itsre,type,islock,title,newdesc,author,authorid,content,time,ip,face,options,other1,other2,other3,other4,other5,statdata,addinfo,alldata) values ('$newlineno','$newlineno','','','$lm','','$forumid','0','0','$timestamp','0','0','0','$articletitle','$articledes','$username','$userid','$articlecontent','$timestamp','$ip','$usericon','$options','$other1','$other2','$other3','$other4','$other5','','','')";
                    $result = bmbdb_query($nquery);
                    $nquery = "insert into {$database_up}posts (id,tid,articletitle,username,usrid,ip,usericon,options,other1,other2,other3,other4,other5,addin,articlecontent,timestamp,forumid,changtime) values ('$newlineno','$newlineno','$articletitle','$username','$userid','$ip','$usericon','$options','$other1','$other2','$other3','$other4','$other5','','$articlecontent','$timestamp','$forumid','$timestamp')";
                    $result = bmbdb_query($nquery);
                    
                    send_suc();

                    echo "<p align=\"center\"><a href=\"topic.php?o=$forumid&amp;f=$newlineno{$sessionid}\">发表完成,点击这里返回.</a></p>";
                } 
            } else {
                ?>
<p align="center"><br/><br/><b>发布主题</b></p>
<p align="left">标题:<input emptyok="false" value="" name="title"/><br/>
内容:<input emptyok="false" name="content"/>
<br/>
<anchor>提交
<go href="post.php?st=2&amp;o=<?php echo $forumid?><?php echo $sessionid?>" method="post">
   <postfield name="title" value="$(title)"/>
   <postfield name="content" value="$(content)"/>
</go>
</anchor></p><?php
            } 
        } 
    } 
} else {
    echo "<p align=\"center\"><a href=\"index.php<?php echo $sessionidq?>\">您没有登录，请返回首页登录。</a></p>";
} 

?>

<p align="center">[<a href="forums.php?forumid=<?php echo $forumid?><?php echo $sessionid?>">返回</a>]</p>
<p align="center">Powered by <a href="http://www.bmforum.com/bmb/wap/">BMForum WAP</a></p>
</card>
</wml>
<?php
function send_suc()
{
    global $newlineno, $userid,$addalimit, $todaypt, $needpostver, $timestamp, $action, $database_up, $bbsdetime, $username, $forumid, $postdontadd, $login_status, $articletitle, $filename, $id_unique, $idpath, $post_money, $post_jifen, $post_jifen_reply, $post_money_reply; 
    // change the information in last_mo.php
    $action = $_GET['a'];
    if ($needpostver == 1) {
		$addalimit = "trashcount=trashcount+1,";
		$addlinestipis = "<br />$others[40]";
	} 
    if ($action == "r" ) $setaddnum = "replysnum = replysnum +1,";
    if ($action != "r" && $needpostver != 1) $setaddnum = "topicnum  = topicnum +1,";

    if ($action == "r") {
        $xnewlineno = $filename;
    } else {
        $xnewlineno = $newlineno;
    } 
    $lasttodaytime_f = gmdate("zY", $todaypt);
    $lasttodaytime_a = gmdate("zY", $timestamp);
    
    if ($lasttodaytime_f != $lasttodaytime_a) {
        $settodayquery = ",todayp=1,todaypt ='$timestamp'";
    } else {
        $settodayquery = ",todayp=todayp+1,todaypt ='$timestamp'";
    } 

    $nquery = "UPDATE {$database_up}forumdata SET {$addalimit} $setaddnum fltitle = '$articletitle',flfname = '$xnewlineno',flposter = '$username',flposttime = '$timestamp' $settodayquery WHERE id='$forumid'";
    $result = bmbdb_query($nquery); 
    // change user's data
    if ($login_status != "2") {
        if ($postdontadd != "1") {
            if ($action == "reply" || $action == "quote") {
                $nquery = "UPDATE {$database_up}userlist SET lastpost='$timestamp',postamount = postamount+1 , point = point+{$post_jifen_reply} , money = money+{$post_money_reply} WHERE userid = '$userid'";
            } else {
                $nquery = "UPDATE {$database_up}userlist SET lastpost='$timestamp',postamount = postamount+1 , point = point+{$post_jifen} , money = money+{$post_money} WHERE userid = '$userid'";
            } 
	        $result = bmbdb_query($nquery);
        } 
    } 
    // change the information in newuser.php
    $query = "SELECT * FROM {$database_up}lastest WHERE pageid='index'";
    $result = bmbdb_query($query);
    $line = bmbdb_fetch_array($result);

    $lasttodaytime = gmdate("zY", $line['lasttodaytime'] + $bbsdetime * 60 * 60);

    if ($lasttodaytime != $lasttodaytime_a) {
        $setaddquery = "todaynew=1,lasttodaytime ='$timestamp',ydaynew='{$line['todaynew']}',";
    } else {
        $maxnewss = $line['todaynew'] + 1;
        if ($maxnewss >= $line['maxnews']) {
            $line['maxnews'] = $maxnewss;
        } 
        $setaddquery = "todaynew=todaynew+1,lasttodaytime ='$timestamp',";
    } 



    $nquery = "UPDATE {$database_up}lastest SET $setaddquery postsnum=postsnum+1,lastposts = '$articletitle',lastpostid = '$xnewlineno',lastposter = '$username',maxnews={$line['maxnews']},lastptime = '$timestamp' WHERE pageid='index'";
    $result = bmbdb_query($nquery);
    refresh_forumcach();
} 
?>