<?php
/*
 BMForum Bulletin Board Systems
 Version : Datium!
 
 This is a freeware, but don't change the copyright information.
 A SourceForge Project.
 Web Site: http://www.bmforum.com
 Copyright (C) Bluview Technology
*/

chdir("..");
include_once("datafile/config.php");
include("wap/global.php");
header("Content-type: text/vnd.wap.wml; charset=utf-8");
echo '<?xml version="1.0" encoding="utf-8" ?><!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">';

?>
<wml>
<card id="BMForum" title="<?php echo $bbs_title?>" newcontext="true">
<p align="center"><strong><?php echo $bbs_title?></strong> <small>@WAP</small><br/></p>
<?php

require_once("datafile/time.php");
function forum_line($forum_type, $id, $detail)
{
    global $forum_line, $xxxcount, $forumlist, $preoutput, $po, $forumnamecolor, $sessionid, $temfilename, $all_count, $all_lastmo, $time_2, $time_1, $script_pos, $forum_admin, $login_status, $idpath, $newpost, $onlyread, $nonewpost, $posticon, $pollicon, $ucomicon, $otherimages, $timestamp, $minoffset;
    echo "<p align=\"left\"><a href=\"forums.php?forumid={$id['id']}{$sessionid}\">" . str_replace("&", "&amp;", $id['bbsname']) . "</a></p>\n";
} 
function get_date_chi($datetime)
{
    global $minoffset, $time_1;
    $datetime = $datetime + ($time_1 * 60 * 60);
    return gmdate("Y/m/d/", $datetime);
} 
function get_add_date($datetime)
{
    global $time_1, $gl;
    $timetmp_a = getdate($datetime);
    @extract($timetmp_a, EXTR_SKIP);
    $hours = $hours - $time_1;
    $mday = $mday-1;
    if ($seconds < 60 && empty($minutes) && empty($hours) && empty($mday) && $mon < 2) {
        return "1 $gl[444]";
    } elseif ($minutes < 60 && empty($hours) && empty($mday) && $mon < 2) {
        return "$minutes $gl[444]";
    } elseif ($hours < 24 && empty($mday) && $mon < 2) {
        return "$hours $gl[445]";
    } elseif ($mday < 7 && $mon < 2) {
        return "$mday $gl[446]";
    } elseif ($mday < 14 && $mday >= 7 && $mon < 2) {
        return "1 $gl[447]";
    } elseif ($mday < 21 && $mday >= 14 && $mon < 2) {
        return "2 $gl[447]";
    } elseif ($mday < 28 && $mday >= 21 && $mon < 2) {
        return "3 $gl[447]";
    } else {
        return "getfulldate";
    } 
} 
function getfulldate($datetime)
{
    global $minoffset, $time_1;
    $datetime = $datetime + ($time_1 * 60 * 60);
    return gmdate("Y/m/d/H:i", $datetime);
} 
function get_time($datetime)
{
    global $minoffset, $time_1;
    $datetime = $datetime + ($time_1 * 60 * 60);
    return gmdate("H:i", $datetime);
} 
function get_date($datetime)
{
    global $minoffset, $time_1;
    $datetime = $datetime + ($time_1 * 60 * 60);
    return gmdate("Y/m/d", $datetime);
} 
$forumid = $_GET['forumid'];

if (@in_array($forumid, $forumidban) || $cannotenter || !$view_list || $forum_pwd) {
    echo"
<p align=\"center\">您无权访问本版块 [<a href=\"index.php{$sessionidq}\">返回</a>]</p>
<p align=\"center\">Powered by <a href=\"http://www.bmforum.com/bmb/wap/\">BMForum WAP</a></p>
</card>
</wml>
";
    exit;
} 
$query = "SELECT * FROM {$database_up}forumdata WHERE blad='$forumid' ORDER BY `showorder` ASC";
$result = bmbdb_query($query);
while ($tmpline = bmbdb_fetch_array($result)) {
    $line[] = $tmpline;
} 
$xxxcount = count($line);
if ($xxxcount != 0) echo "<p align=\"center\"><strong>[版块列表]</strong></p>";
for($i = 0;$i < $xxxcount;$i++) {
    if ($line[$i]['type'] == 'subforum' || (($sxfourmrow[$i]['type'] == 'subselection' || ($line[$i]['type'] == 'subforumhid' && $ugnums != 6) || $sxfourmrow[$i]['type'] == 'subhidden') && $enter_tb == 1) || $line[$i]['type'] == 'subselection' || $line[$i]['type'] == 'subformer' || $line[$i]['type'] == 'subforumhid' || $line[$i]['type'] == 'sublocked') forum_line($line[$i]['type'], $line[$i], $line);
} 

$page = $_GET['page'];
if (empty($page)) $page = 1;

echo "<p align=\"center\"><strong>[主题列表]</strong></p>";

get_forum_info();

$orderby = "ORDER BY `toptype` DESC,`changetime` DESC";
$jinhuasql = $chooseby = $hasacount = "";
$trashq = "AND ttrash=0";
$jinhuasql = "islock > 1 AND";
$hasacount = $digestcount;

@include_once("datafile/cache/pin_thread.php");

$query_pagea = "";
if (empty($forum_cid)) $forum_cid = "XXXXXXXXXXXX";
    
$intopthread = $count_pint["$forum_cid"] ? $topthread['ALL'] : substr($topthread['ALL'] ,0 ,-1);
$intopthread .=  substr($topthread["$forum_cid"] ,0 ,-1);

$total_pin = $count_pint['ALL'] + $count_pint["$forum_cid"];


if ($page == 1 && $total_pin > 0) {
    $query = "SELECT * FROM {$database_up}threads WHERE tid in ($intopthread) $trashq $chooseby $orderby";
    $xresult = bmbdb_query($query);
    $counttopsnum = $topsnum = bmbdb_num_rows($xresult);
} elseif ($page != 1 && $total_pin > 0) {
    $query = "SELECT COUNT(tid) FROM {$database_up}threads WHERE tid in ($intopthread) $trashq $chooseby $orderby";
    $xresult = bmbdb_query($query);
    $xresultrow = bmbdb_fetch_array($xresult);
    $topsnum = $xresultrow['COUNT(tid)'];
    $counttopsnum = $topsnum + $pincount;
} else {
    $counttopsnum = $topsnum;
}


$thislimit = $perpage * $page;
$lastlimit = $perpage * ($page-1);

if ($ttopicnum < $perpage) $perpage = $ttopicnum;

$query = "SELECT * FROM {$database_up}threads WHERE forumid='$forumid' AND toptype!=9 AND toptype!=8 $trashq $chooseby $orderby LIMIT $lastlimit,$perpage";
$result = bmbdb_query($query);
$topicsn = bmbdb_num_rows($result) + $topsnum;
$count = max(0, $ttopicnum - $counttopsnum);
$x = 0;
$xxi = 0;
for ($x = 0;$x < $topicsn;$x++) {
    if ($x < $topsnum) $row = bmbdb_fetch_array($xresult);
    else $row = bmbdb_fetch_array($result);
    
    $showto[] = $row;
} 

for ($i = 0; $i < $topicsn; $i++) {
    if ($showto[$i]['tid'] != "") {
        echo "<p align=\"left\"><a href=\"topic.php?f={$showto[$i]['tid']}&amp;o=$forumid{$sessionid}\">" . htmlspecialchars(stripslashes($showto[$i]['title'])) . "</a><br/>{$showto[$i]['author']} 发表于 " . getfulldate($showto[$i]['time']) . "</p>\n";
    } 
} 
if ($count == 0) {
    $pagemin = $pagemax = $page = $maxpageno = 1;
}else{
    if ($count % $perpage == 0) $maxpageno = max(1, $count / $perpage);
    else $maxpageno = max(1, floor($count / $perpage) + 1);
    if ($page == "last" || $page > $maxpageno) $page = $maxpageno;
    $pagemin = max(1, min(($page-1) * $perpage , $count-1));
    $pagemax = max(1, min($pagemin + $perpage-1, $count-1) + 1);
}
if ($maxpageno == 1) $pageinfos .= "<strong>当前只有一页</strong>";
else {
    $pageinfos .= "[ ";
    $nextpage = $page + 1;
    $previouspage = $page-1;
    $maxpagenum = $page + 4;
    $minpagenum = $page-4;
    if ($page >= 2) $pageinfos .= "<strong><a href=\"forums.php?forumid=$forumid&amp;page=$previouspage{$sessionid}\">&lt;</a></strong> ";
    else $pageinfos .= "<strong>&lt;</strong> ";
    if ($page <= $maxpageno-1) $pageinfos .= "<strong><a href=\"forums.php?forumid=$forumid&amp;page=$nextpage{$sessionid}\">&gt;</a></strong> ";
    else $pageinfos .= "<strong>&gt;</strong> ";

    $pageinfos .= "<strong><a href=\"forums.php?forumid=$forumid&amp;page={$sessionid}\">&lt;&lt;</a></strong> <strong><a href=\"forums.php?forumid=$forumid&amp;page=$maxpageno{$sessionid}\">&gt;&gt;</a></strong> ";
    for ($i = $minpagenum; $i <= $maxpagenum; $i++) {
        if ($i > 0 && $i <= $maxpageno) {
            if ($i == $page) {
                $pageinfos .= " <strong>$i</strong> ";
            } else {
                $pageinfos .= " <strong><a href=\"forums.php?forumid=$forumid&amp;page=$i{$sessionid}\">$i</a></strong> ";
            } 
        } 
    } 
    $pageinfos .= "]";
} 

?>

<p align="center"><?php echo $pageinfos?> [<a href="index.php<?php echo $sessionidq?>">返回</a>] [<a href="post.php?o=<?php echo $forumid?><?php echo $sessionid?>">发帖</a>]</p>
<p align="center">Powered by <a href="http://www.bmforum.com/bmb/wap/">BMForum WAP</a></p>
</card>
</wml>
