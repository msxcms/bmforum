<?php
/*
 BMForum Bulletin Board Systems
 Version : Datium!
 
 This is a freeware, but don't change the copyright information.
 A SourceForge Project.
 Web Site: http://www.bmforum.com
 Copyright (C) Bluview Technology
*/

chdir("..");
include_once("datafile/config.php");
include("wap/global.php");
header("Content-type: text/vnd.wap.wml; charset=utf-8");
echo '<?xml version="1.0" encoding="utf-8" ?><!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">';

?>
<wml>
<card id="BMForum" title="<?php echo $bbs_title?>" newcontext="true">
<p align="center"><strong><?php echo $bbs_title?></strong> <small>@WAP</small><br/></p>
<?php
require_once("datafile/time.php");
function get_date_chi($datetime)
{
    global $minoffset, $time_1;
    $datetime = $datetime + ($time_1 * 60 * 60);
    return gmdate("Y/m/d/", $datetime);
} 
function get_add_date($datetime)
{
    global $time_1, $gl;
    $timetmp_a = getdate($datetime);
    @extract($timetmp_a, EXTR_SKIP);
    $hours = $hours - $time_1;
    $mday = $mday-1;
    if ($seconds < 60 && empty($minutes) && empty($hours) && empty($mday) && $mon < 2) {
        return "1 $gl[444]";
    } elseif ($minutes < 60 && empty($hours) && empty($mday) && $mon < 2) {
        return "$minutes $gl[444]";
    } elseif ($hours < 24 && empty($mday) && $mon < 2) {
        return "$hours $gl[445]";
    } elseif ($mday < 7 && $mon < 2) {
        return "$mday $gl[446]";
    } elseif ($mday < 14 && $mday >= 7 && $mon < 2) {
        return "1 $gl[447]";
    } elseif ($mday < 21 && $mday >= 14 && $mon < 2) {
        return "2 $gl[447]";
    } elseif ($mday < 28 && $mday >= 21 && $mon < 2) {
        return "3 $gl[447]";
    } else {
        return "getfulldate";
    } 
} 
function getfulldate($datetime)
{
    global $minoffset, $time_1;
    $datetime = $datetime + ($time_1 * 60 * 60);
    return gmdate("Y/m/d/H:i", $datetime);
} 
function get_time($datetime)
{
    global $minoffset, $time_1;
    $datetime = $datetime + ($time_1 * 60 * 60);
    return gmdate("H:i", $datetime);
} 
function get_date($datetime)
{
    global $minoffset, $time_1;
    $datetime = $datetime + ($time_1 * 60 * 60);
    return gmdate("Y/m/d", $datetime);
} 
$forumid = $_GET['o'];
if (in_array($forumid, $forumidban) || $cannotenter || !$p_read_post || $forum_pwd) {
    echo<<<EOT
<p align="center">您无权访问本主题 [<a href="index.php{$sessionidq}">返回</a>]</p>
<p align="center">Powered by <a href="http://www.bmforum.com/bmb/wap/">BMForum WAP</a></p>
</card>
</wml>
EOT;
    exit;
} 
$filename = $_GET['f'];
$page = $_GET['page'];
if (empty($page)) $page = 1;

$query = "SELECT * FROM {$database_up}threads WHERE tid='$filename'";
$result = bmbdb_query($query);
$row = bmbdb_fetch_array($result);
$threadrow = $row;
$replyerlist = explode("|", $row['replyer']);
$forumid = $row[forumid];
$thtoptype = $row[toptype];
$topic_reply = $row['replys'];

$count = $topic_reply + 1;

if ($count % $read_perpage == 0) $maxpageno = $count / $read_perpage;
else $maxpageno = floor($count / $read_perpage) + 1;
if ($page == "last" || $page > $maxpageno) $page = $maxpageno;
$pagemin = min(($page-1) * $read_perpage , $count-1);
$pagemax = min($pagemin + $read_perpage-1, $count-1);

$pagemaxq = $pagemax + 1;

$aquery = "SELECT o.* FROM {$database_up}posts o WHERE o.tid='$filename' ORDER BY o.id ASC LIMIT $pagemin,$pagemaxq";
$aresult = bmbdb_query($aquery);

for ($i = $pagemin; $i <= $pagemax; $i++) {
    $line = bmbdb_fetch_array($aresult);
    if ($line['articlecontent'] == "") continue;

    $icountforend = count($articlelist);
    // list("articletitle"=>$title,"username"=>$author,"articlecontent"=>$content,"timestamp"=>$time,"ip"=>$aaa,"usericon"=>$icon,"options"=>$usesign,"other1"=>$bym,"other2"=>$bymuser,"other3"=>$uploadfilename,"other4"=>$editinfo,"other5"=>$sellmoney)=$line;
    $title = htmlspecialchars(stripslashes($line[articletitle]));
    $author = $line[username];
    $content = stripslashes($line[articlecontent]);
    $time = $line[timestamp];
    $aaa = $line[ip];
    $icon = $line[usericon];
    $usesign = $line[options];
    $bym = $line[other1];
    $bymuser = $line[other2];
    $uploadfilename = $line[other3];
    $editinfo = $line[other4];
    $sellmoney = $line[other5];

    $content = str_replace("&", "&amp;", $content);
    $content = str_replace("<", "&lt;", $content);
    $content = str_replace(">", "&gt;", $content);
    $content = str_replace("&lt;br&gt;", "<br>", $content);

    echo "<p align=\"left\"><strong>" . $title. "</strong><br/>" . str_replace("&lt;HTML::BR&gt;", "<br/>", strip_tags(str_replace("<br>", "<HTML::BR>", $content))) . "<br/><strong>$author</strong> 发表于 " . getfulldate($time) . "</p>\n";
} 

if ($count % $read_perpage == 0) $maxpageno = $count / $read_perpage;
else $maxpageno = floor($count / $read_perpage) + 1;
if ($page == "last" || $page > $maxpageno) $page = $maxpageno;
$pagemin = min(($page-1) * $read_perpage , $count-1);
$pagemax = min($pagemin + $read_perpage-1, $count-1);

if ($maxpageno == 1) $pageinfos .= "<strong>当前只有一页</strong>";
else {
    $pageinfos .= "[ ";
    $nextpage = $page + 1;
    $previouspage = $page-1;
    $maxpagenum = $page + 4;
    $minpagenum = $page-4;
    if ($page >= 2) $pageinfos .= "<strong><a href=\"topic.php?o=$forumid&amp;f=$filename&amp;page=$previouspage{$sessionid}\">&lt;</a></strong> ";
    else $pageinfos .= "<strong>&lt;</strong> ";
    if ($page <= $maxpageno-1) $pageinfos .= "<strong><a href=\"topic.php?o=$forumid&amp;f=$filename&amp;page=$nextpage{$sessionid}\">&gt;</a></strong> ";
    else $pageinfos .= "<strong>&gt;</strong> ";

    $pageinfos .= "<strong><a href=\"topic.php?o=$forumid&amp;f=$filename&amp;page={$sessionid}\">&lt;&lt;</a></strong> <strong><a href=\"topic.php?o=$forumid&amp;f=$filename&amp;page=$maxpageno{$sessionid}\">&gt;&gt;</a></strong> ";
    for ($i = $minpagenum; $i <= $maxpagenum; $i++) {
        if ($i > 0 && $i <= $maxpageno) {
            if ($i == $page) {
                $pageinfos .= " <strong>$i</strong> ";
            } else {
                $pageinfos .= " <strong><a href=\"topic.php?o=$forumid&amp;f=$filename&amp;page=$i{$sessionid}\">$i</a></strong> ";
            } 
        } 
    } 
    $pageinfos .= "]";
} 
function diplay_attachment($start, $countas, $lineid, $getcode) {
    
}
?>

<p align="center"><?php echo $pageinfos?> [<a href="forums.php?forumid=<?php echo $forumid?><?php echo $sessionid?>">返回</a>] [<a href="post.php?o=<?php echo $forumid?>&amp;f=<?php echo $filename?>&amp;a=r<?php echo $sessionid?>">回复</a>]</p>
<p align="center">Powered by <a href="http://www.bmforum.com/bmb/wap/">BMForum WAP</a></p>
</card>
</wml>