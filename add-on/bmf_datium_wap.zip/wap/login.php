<?php
/*
 BMForum Bulletin Board Systems
 Version : Datium!
 
 This is a freeware, but don't change the copyright information.
 A SourceForge Project.
 Web Site: http://www.bmforum.com
 Copyright (C) Bluview Technology
*/

chdir("..");
include_once("datafile/config.php");
include_once("wap/global.php");
if ($_GET['a'] == "out") {
    $_SESSION["username"] = "";
    $_SESSION["password"] = "";
} 
$_SESSION["username"] = $_POST['user'];
$_SESSION["password"] = md5($_POST['pass']);
header("Content-type: text/vnd.wap.wml; charset=utf-8");
echo '<?xml version="1.0" encoding="utf-8" ?><!DOCTYPE wml PUBLIC "-//WAPFORUM//DTD WML 1.1//EN" "http://www.wapforum.org/DTD/wml_1.1.xml">';

?>
<wml>
<card id="BMForum" title="<?php echo $bbs_title?>" newcontext="true">
<p align="center"><b><?php echo $bbs_title?></b> <small>@WAP</small><br/></p>
<p align="center"><a href="index.php<?php echo $sessionidq?>">操作完成,点击这里返回</a></p>
<p align="center">Powered by <a href="http://www.bmforum.com/bmb/wap/">BMForum WAP</a></p>
</card>
</wml>