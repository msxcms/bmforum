<?php
/*
 BMForum Bulletin Board Systems
 Version : Datium!
 
 This is a freeware, but don't change the copyright information.
 A SourceForge Project.
 Web Site: http://www.bmforum.com
 Copyright (C) Bluview Technology
*/
// 输入禁止由 WAP 访问的版块 ID
$forumidbanned = "100,1001"; // 逗号隔开，如 99,100,101


/* 
  其余部分非专业人士勿动 
*/
require("include/db/db_{$sqltype}.php");
require("datafile/time.php");
include_once("datafile/cache/usergroup.php");
include_once("datafile/cache/forumdata.php");
ini_set('session.use_cookies', 0);

if (!$sess_cust) @session_save_path("tmp");
@session_name('bmsess');
@session_cache_limiter("nocache");
@session_start();

$sessionid = "&amp;bmsess=" . session_id();
$sessionidq = "?bmsess=" . session_id();

$forumidban = explode(",", $forumidbanned);
bmbdb_connect($db_server, $db_username, $db_password, $db_name, 0, $mysqlchar);
$forumid = $_GET['forumid'] ? $_GET['forumid'] : $_GET['o'];
$ugnums = 6;
$usermoney = $userpoint = $userbym = $postamount = $login_status = 0;

if ($_SESSION['username'] && $_SESSION['password']) checkpass($_SESSION['username'], $_SESSION['password']);
global_usergroup();
get_forum_info();

for($i = 0;$i < $forumscount;$i++) {
    if ((($sxfourmrow[$i]['type'] == 'selection' || $sxfourmrow[$i]['type'] == 'subselection' || $sxfourmrow[$i]['type'] == 'hidden' || $sxfourmrow[$i]['type'] == 'subhidden') && $enter_tb != 1) || (($sxfourmrow[$i]['type'] == 'former' || $sxfourmrow[$i]['type'] == 'subformer' || $sxfourmrow[$i]['type'] == 'forumhid' || $sxfourmrow[$i]['type'] == 'subforumhid') && $ugnums == 6) || $sxfourmrow[$i]['type'] == 'closed' || $sxfourmrow[$i]['type'] == 'subclosed') {
        $forumidban[] = $sxfourmrow[$i]['id'];
    } 
} 

if ($_GET['f'] != "" && ($p_read_post == "0" || $userpoint < $read_allow_ww)) {
    $cannotenter = 1;
} 
if (($spusergroup == "1" && $enter_this_forum == "0") || $view_list == 0) $cannotenter = 1;

check_forum_permission();

function check_forum_permission()
{
    global $usermoney, $cannotenter, $ajax_online, $enter_this_forum, $gl, $forumid, $forum_name, $p_read_post, $pgo, $ajax_reply, $error, $language, $read_allow_ww, $spusergroup, $postamount, $userbym , $forum_ford, $footer_copyright, $headername, $footername, $read_alignment, $html_lang, $enter_allow_ww, $enter_this_forum, $userpoint, $enter_tb, $plugyescolor, $usertype, $forum_type, $forumid, $username, $login_status, $limitlist, $forum_admin, $verandproname, $otherimages, $bbs_title, $add_title, $cssinfo, $login_status, $ads_select, $admin_email, $site_url, $showtime, $site_name, $writefilenum, $readfilenum, $begin_time, $temfilename, $gl;
	$ford = explode("_", $forum_ford);
	if ($ford[0] == 1 && ($postamount < $ford[1] || $userbym < $ford[2] || $usermoney < $ford[3]) && $usertype[21] != "1" && $usertype[22] != "1") {
		$cannotenter = 1;
	} 

} 
function checkpass($username, $password)
{
    global $database_up, $userpoint, $userid, $postamount, $userbym, $usermoney, $ugnums;
    $query = "SELECT username,pwd,ugnum,userid,point,postamount,money FROM {$database_up}userlist WHERE username='$username'";
    $result = bmbdb_query($query);
    $row = bmbdb_fetch_array($result);
    $userid = $row['userid'];
    if ($password == $row['pwd']) {
        $ugnums = $row['ugnum'];
        $postamount = $row['postamount'];
        $userbym = $row['point'];
        $userpoint = floor($userbym / 10);
        $usermoney = $row['money'];
        return 1;
    } else {
        $ugnums = 6;
        $usermoney = $userpoint = $userbym = $postamount = $login_status = 0;
        return 0;
    } 
} 
function global_usergroup()
{
    global $usertype, $read_allow_ww, $p_read_post, $post_money, $post_jifen,$post_money_reply, $post_jifen_reply, $enter_tb, $canpost, $canreply, $bmfcode_post, $usergroupdata, $ugnums, $view_list;
    $usertype = explode("|", $usergroupdata[$ugnums]);
    list($groupname, $groupimg, $systemg, $canpost, $canreply, $canpoll, $canvote, $max_sign_length, $sign_use_bmfcode, $bmfcode_sign['pic'], $bmfcode_sign['flash'], $bmfcode_sign['fontsize'], $enter_tb, $send_msg, $max_post_length, $short_msg_max, $send_msg_max, $use_own_portait, $swf, $max_upload_size, $upload_type_available, $supermod, $admin, $groupimg2, $mod, $max_upload_num, $html_codeinfo, $max_daily_upload_size, $logon_post_second, $post_sell_max, $del_true, $del_rec, $can_rec, $delrmb, $post_money, $deljifen, $post_jifen, $allow_upload, $max_upload_post, $opencutusericon, $openupusericon, $max_avatars_upload_size, $max_avatars_upload_post, $upload_avatars_type_available, $maxwidth, $maxheight, $p_read_post, $view_list, $lock_true, $del_reply_true, $edit_true, $move_true, $copy_true, $ztop_true, $ctop_true, $uptop_true, $bold_true, $sej_true, $autorip_true, $ttop_true, $modcenter_true, $modano_true, $modban_true, $clean_true, $showpic, $post_money_reply, $post_jifen_reply, $del_self_topic, $del_self_post, $bmfcode_post['pic'], $bmfcode_post['reply'], $bmfcode_post['jifen'], $bmfcode_post['sell'], $bmfcode_post['flash'], $bmfcode_post['mpeg'], $bmfcode_post['iframe'], $bmfcode_post['fontsize'], $bmfcode_post['hpost'], $bmfcode_post['hmoney'], $allow_forb_ub, $can_visual_post, $member_list, $search_fun, $nwpost_list, $porank_list, $gvf, $see_amuser, $view_recybin, $post_allow_ww, $re_allow_ww, $poll_allow_ww, $vote_allow_ww, $enter_allow_ww, $pri_allow_ww, $forum_allow_ww, $recy_allow_ww, $read_allow_ww) = $usertype;
} 
function get_forum_info()
{
    global $ttopicnum, $read_allow_ww, $forum_ford, $post_money,  $post_jifen,$post_money_reply, $post_jifen_reply, $needpostver, $todaypt, $forum_type, $forumscount, $canpost, $canreply, $sxfourmrow, $enter_this_forum, $spusergroup, $forum_pwd, $p_read_post, $bmfcode_post, $ugnums, $view_list, $noheldtop, $forum_cid, $database_up, $forumid;
    for($i = 0;$i < $forumscount;$i++) {
        if ($sxfourmrow[$i]['id'] == $forumid) {
            $detail = $sxfourmrow[$i];
        } 
    } 

    $ttopicnum = $detail['topicnum'];
    $forum_type = $detail['type'];
    $spusergroup = $detail['spusergroup'];
    $forum_cid = $detail['forum_cid'];
    $forum_pwd = $detail['forumpass'];
    $forum_ford = $detail['forum_ford'];
    $guestpost = explode("_", $detail['guestpost']);
    $noheldtop = $guestpost[2];
    $needpostver = $detail['needpostver'];
	$todaypt = $detail['todaypt'];

    if ($spusergroup == "1") {
        $usergroupdata = explode("\n", $detail['usergroup']);
        $usertype = explode("|", $usergroupdata[$ugnums]);
        list($groupname, , , $canpost, $canreply, $canpoll, $canvote, , , , , , $enter_this_forum, , $max_post_length, , , , , $max_upload_size, $upload_type_available, , , , $mod, $max_upload_num, $html_codeinfo, $max_daily_upload_size, $logon_post_second, $post_sell_max, $del_true, $del_rec, $can_rec, $delrmb, $post_money, $deljifen, $post_jifen, $allow_upload, $max_upload_post, , , , , , , , $p_read_post, $view_list, $lock_true, $del_reply_true, $edit_true, $move_true, $copy_true, $ztop_true, $ctop_true, $uptop_true, $bold_true, $sej_true, $autorip_true, $ttop_true, $modcenter_true, $modano_true, $modban_true, $clean_true, , $post_money_reply, $post_jifen_reply, $del_self_topic, $del_self_post, $bmfcode_post['pic'], $bmfcode_post['reply'], $bmfcode_post['jifen'], $bmfcode_post['sell'], $bmfcode_post['flash'], $bmfcode_post['mpeg'], $bmfcode_post['iframe'], $bmfcode_post['fontsize'], $bmfcode_post['hpost'], $bmfcode_post['hmoney'], $allow_forb_ub, $can_visual_post, $member_list, $search_fun, $nwpost_list, $porank_list, $gvf, $see_amuser, $view_recybin, $post_allow_ww, $re_allow_ww, $poll_allow_ww, $vote_allow_ww, $enter_allow_ww, $pri_allow_ww, $forum_allow_ww, $recy_allow_ww, $read_allow_ww) = explode("|", $usergroupdata[$ugnums]);
    } 
} 
function readfromfile($file_name)
{
    if (file_exists($file_name)) {
        $filenum = fopen($file_name, "r");
        flock($filenum, LOCK_SH);
        $file_data = @fread($filenum, @filesize($file_name));
        fclose($filenum);
        return $file_data;
    } 
} 
function writetofile($file_name, $data, $method = "w")
{
    $filenum = fopen($file_name, $method);
    flock($filenum, LOCK_EX);
    $file_data = fwrite($filenum, $data);
    fclose($filenum);
    return $file_data;
} 
function safe_convert($d)
{
    $d = htmlspecialchars($d);
    $d = str_replace("&amp;", "&", $d);
    $d = str_replace("&#", "&amp;#", $d);
    $d = str_replace("\t", "", $d);
    $d = str_replace("javascript", "ｊａｖａｓｃｒｉｐｔ", $d);
    $d = str_replace("vbscript", "ｖｂｓｃｒｉｐｔ", $d);
    $d = str_replace("\r", "<br>", $d);
    $d = str_replace("\n", "", $d);
    $d = str_replace("|", "│", $d);
    $d = str_replace("  ", " &nbsp;", $d);
    return $d;
} 
$timestamp = time();
$ip = $_SERVER['REMOTE_ADDR'];
$ip1 = $_SERVER['HTTP_X_FORWARDED_FOR'];
if (($ip1 != "") && ($ip1 != "unknown")) $ip = $ip1;
// Refresh the Forum's Cache to file from database
function refresh_forumcach()
{
    global $database_up;
    
    $nquery = "SELECT * FROM {$database_up}forumdata ORDER BY `showorder` ASC";
    $nresult = bmbdb_query($nquery);
    while (false !== ($fourmrow = bmbdb_fetch_array($nresult))) {
        $xfourmrow[] = $fourmrow;
    } 
    $wrting = "<?php \n";
    $count = count($xfourmrow);
    for ($i = 0; $i < $count; $i++) {
        $tmp = $xfourmrow[$i];
        foreach ($tmp as $key => $value) {
            if ($key != "fltitle") $wrting .= "\$sxfourmrow[$i]['{$key}']='" . str_replace("\\\'", "\\\\\'", str_replace("'", "\'", $value)) . "'; \n";
            else $wrting .= "\$sxfourmrow[$i]['{$key}']='" . str_replace("&amp;#039;", "&#039;", str_replace("'", "&#039;", htmlspecialchars(bmb_unhtmlentities($value)))) . "'; \n";
        } 
        $forumscount++;
    } 
    $wrting .= "\$forumscount='$forumscount';";
    writetofile("datafile/cache/forumdata.php", $wrting);
} 
function bmb_unhtmlentities($string) 
{
	if (@function_exists("html_entity_decode")) {
        return html_entity_decode($string);
	} else {
        $trans_tbl = get_html_translation_table(HTML_ENTITIES);
        $trans_tbl = array_flip($trans_tbl);
        return strtr($string, $trans_tbl);
    }
}
